package MarsRoverCommunication;

public interface CommunicationInstructions {
	void communicationInstructionsOfVehicle();
	void parseInstructions(String instructions);
}
